<div class="rey-overlay rey-overlay--header" style="opacity:0;"></div>
<div class="rey-overlay rey-overlay--header-top" style="opacity:0;"></div>
